#!/system/bin/sh
# Reapplied on every start. Keep this script idempotent.
set -e
hotfix_bind files/0 /system/etc/andr36oid-hotfix.sh
