#!/system/bin/sh
# andr36oid USB debug hotfix. Runs before zygote on every boot; idempotent.
# Keeps the OTG port in device (peripheral) mode with adb and USB debugging on,
# so a computer stays connected without re-picking Settings > USB mode. The kernel
# defaults the port to host on every start, and the framework turns USB debugging
# back off when SystemUI comes up, so a small detached monitor re-asserts both.
#
# DEBUGGING ONLY. While installed the OTG port is a USB device for a computer: do
# not plug a charger or a powered/OTG accessory (controller, stick, keyboard,
# drive) into the OTG port. Charge as usual through the separate DC charge port.
# Delete the zip from BOOT/hotfix to get normal USB mode switching back.
set -u
OTG=/sys/devices/platform/ff2c0000.syscon/ff2c0000.syscon:usb2-phy@100/otg_mode

# Keep adb among the USB gadget functions (andr36oid-usb-drive honors adb here).
setprop persist.sys.usb.config adb
# Device/peripheral mode now; the kernel default is host and is not kept across a restart.
[ -w "$OTG" ] && echo peripheral > "$OTG" 2>/dev/null

# Detached monitor: the framework turns USB debugging back off when SystemUI
# (re)starts, so re-assert it, the gadget function and the port mode whenever one
# has been reset. It only writes when something is off, so it is quiet once stable.
setsid sh -c '
	OTG=/sys/devices/platform/ff2c0000.syscon/ff2c0000.syscon:usb2-phy@100/otg_mode
	while true; do
		[ "$(settings get global adb_enabled 2>/dev/null)" = 1 ] || settings put global adb_enabled 1 2>/dev/null
		[ "$(settings get global development_settings_enabled 2>/dev/null)" = 1 ] || settings put global development_settings_enabled 1 2>/dev/null
		case ",$(getprop persist.sys.usb.config)," in *,adb,*) ;; *) setprop persist.sys.usb.config adb ;; esac
		[ -w "$OTG" ] && [ "$(cat "$OTG" 2>/dev/null)" != peripheral ] && echo peripheral > "$OTG" 2>/dev/null
		sleep 10
	done
' </dev/null >/dev/null 2>&1 &
