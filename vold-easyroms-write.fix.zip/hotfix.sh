#!/system/bin/sh
# Reapplied on every start. Keep this script idempotent.
set -e
# Swap in the fixed vold.
hotfix_bind files/0 /system/bin/vold
# vold starts at early-fs with the old binary, before this script runs, so it is
# already live. Restart it now - still before zygote and system_server - so the
# fixed binary is what mounts EASYROMS for apps, with write access.
setprop ctl.restart vold
